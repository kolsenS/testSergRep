    $(document).ready(function() {
      const counterMin=10000;
      const counterMax=11071;
      var pathImg='./img/H'
      var counter=counterMin;
      var statusPlay=false;
      var timerplay=0;
      var statusRewL=false;
      var statusRewR=false;
      var statusQual=true;
      var $still=$('<img>', {src: pathImg+counter+'.jpg'})
            .css('width', 'auto')
            .css('height', '100%')
            .appendTo('#screen');

      function lookDown() {
        clearInterval(timerplay);
        statusPlay=false;
        statusRewL=false;
        statusRewR=false;
      };

      function lookUp() {
        var delta=arguments[0];
        var lag=arguments[1];
        timerplay=setInterval( function(){
            $still.attr('src', pathImg+counter+'.jpg');
            counter+=delta;
            $('#slider').val(counter);
            limits();
        }, lag);
      };

      function limits() {
        if (counter===counterMin) {
            lookDown();
        };
        if (counter===counterMax) {
            lookDown();
            counter=counterMin;
            $('#slider').val(counter);
        };
      };

      function effectPressBtn() {
        $(arguments[0]).css('opacity', '0.6').delay(190).queue(function () {
            $(this).css('opacity', '1');
            $(this).dequeue();
        });
      };

    	$('#start').click( function(e){
    		e.preventDefault();
    		$('#overlay').fadeIn(350, function(){
    				$('#modal_win')
    				.css('display', 'block')
    				.animate({opacity: 1, top: '50%'}, 250);
    		});
    	});

      $('#play').click( function(e){
        if ((statusPlay && statusRewL) || (statusPlay && statusRewR)) {
            lookDown();
        };
        if (!statusPlay){
            e.preventDefault();
            effectPressBtn('#play');
            statusPlay=true;
            lookUp(1, 41);
        };
      });

      $('#screen').click( function(e){
        if (statusPlay){
            lookDown();
        } else {
            e.preventDefault();
            lookDown();
            statusPlay=true;
            lookUp(1, 41);
        };
      });

      $('#pause').click( function(e){
        if (statusPlay){
            e.preventDefault();
            effectPressBtn('#pause');
            lookDown();
        };
      });

      $('#rewl').click( function(e){
        if (counter>counterMin && !statusRewL) {
            e.preventDefault();
            effectPressBtn('#rewl');
            lookDown();
            statusRewL=true;
            statusPlay=true;
            lookUp(-1, 12);
        };
      });

      $('#rewr').click( function(e){
        if (counter<counterMax && !statusRewR) {
            e.preventDefault();
            effectPressBtn('#rewr');
            lookDown();
            statusRewR=true;
            statusPlay=true;
            lookUp(1, 12);
        };
      });

      $('#lq').click( function(e){
        if (statusQual) {
            e.preventDefault();
            $('#lq').css('opacity', '0.6');
            $('#hq').css('opacity', '1');
            lookDown();
            counter=counterMin;
            $('#slider').val(counter);
            pathImg='./img/L';
            $still.attr('src', pathImg+counter+'.jpg');
            statusQual=false;
        };
      });

      $('#hq').click( function(e){
        if (!statusQual) {
            e.preventDefault();
            $('#lq').css('opacity', '1');
            $('#hq').css('opacity', '0.6');
            lookDown();
            counter=counterMin;
            $('#slider').val(counter);
            pathImg='./img/H';
            $still.attr('src', pathImg+counter+'.jpg');
            statusQual=true;
        };
      });

      $(document).keypress( function(e) {
        if (e.which===32) {
            if (statusPlay){
                lookDown();
            } else {
                e.preventDefault();
                lookDown();
                statusPlay=true;
                lookUp(1, 41);
            };
        };
      });

      $('#screen, #slider').bind('mousewheel DOMMouseScroll', function(e){
        e.preventDefault();
        if (e.originalEvent.wheelDelta>0 && counter<counterMax) {counter+=1};
        if (e.originalEvent.wheelDelta<0 && counter>counterMin) {counter-=1};
        limits();
        $('#slider').val(counter);
        $still.attr('src', pathImg+counter+'.jpg');
      });

      $('#slider').on('change input', function(e){
        e.preventDefault();
        counter=parseInt($('#slider').val());
        limits();
        $still.attr('src', pathImg+counter+'.jpg');
      });

    	$('#overlay').click( function(){
    		$('#modal_win')
    			.animate({opacity: 0, top: '45%'}, 250, function(){
    					$(this).css('display', 'none');
    					$('#overlay').fadeOut(350);
    			});
    	});
    });
